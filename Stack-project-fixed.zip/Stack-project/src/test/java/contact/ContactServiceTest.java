package contact;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {

	
	@Test
	@DisplayName("Update First Name.")
	@Order(1)
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		service.addContact("Smith", "Johnson", "2155551234", "123 Main Street");
		// Get the ID of the first contact (should be "0")
		String firstContactId = service.contactList.get(0).getContactID();
		service.updateFirstName("Logan", firstContactId);
		service.displayContactList();
		assertEquals("Logan", service.getContact(firstContactId).getFirstName(), "First name was not updated.");
	}

	@Test
	@DisplayName("Update Last Name.")
	@Order(2)
	void testUpdateLastName() {
		ContactService service = new ContactService();
		service.addContact("Smith", "Johnson", "2155551234", "123 Main Street");
		// Get the ID of the first contact (should be "0")
		String firstContactId = service.contactList.get(0).getContactID();
		service.updateLastName("Ella", firstContactId);
		service.displayContactList();
		assertEquals("Ella", service.getContact(firstContactId).getLastName(), "Last name was not updated.");
	}

	@Test
	@DisplayName("Test to update phone number.")
	@Order(3)
	void testUpdatePhoneNumber() {
		ContactService service = new ContactService();
		service.addContact("Smith", "Johnson", "2155551234", "123 Main Street");
		// Get the ID of the first contact (should be "0")
		String firstContactId = service.contactList.get(0).getContactID();
		service.updateNumber("3333311111", firstContactId);
		//service.displayContactList();
		assertEquals("3333311111", service.getContact(firstContactId).getNumber(), "Phone number was not updated.");
	}

	@Test
	@DisplayName("Test to update address.")
	@Order(4)
	void testUpdateAddress() {
		ContactService service = new ContactService();
		service.addContact("Smith", "Johnson", "2155551234", "123 Main Street");
		// Get the ID of the first contact (should be "0")
		String firstContactId = service.contactList.get(0).getContactID();
		service.updateAddress("555 College Ave", firstContactId);
		service.displayContactList();
		assertEquals("555 College Ave", service.getContact(firstContactId).getAddress(), "Address was not updated.");
	}

	@Test
	@DisplayName("Test to ensure that service correctly deletes contacts.")
	@Order(5)
	void testDeleteContact() {
		ContactService service = new ContactService();
		service.addContact("Smith", "Johnson", "2155551234", "123 Main Street");
		// Get the ID of the first contact (should be "0")
		String firstContactId = service.contactList.get(0).getContactID();
		service.deleteContact(firstContactId);
		service.displayContactList();
		assertEquals(0, service.contactList.size(), "The contact was not deleted.");
	}

	@Test
	@DisplayName("Test to ensure that service can add a contact.")
	@Order(6)
	void testAddContact() {
		ContactService service = new ContactService();
		service.addContact("Smith", "Johnson", "2155551234", "123 Main Street");
		service.displayContactList();
		// Get the ID of the first contact (should be "0")
		String firstContactId = service.contactList.get(0).getContactID();
		assertNotNull(service.getContact(firstContactId), "Contact was not added correctly.");
	}

}