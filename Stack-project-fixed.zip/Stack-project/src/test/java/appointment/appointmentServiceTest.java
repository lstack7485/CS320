package appointment;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	
	private Date Date(int year, int month, int day) {
		Calendar cal = Calendar.getInstance();
		cal.set(year, month, day);
		return cal.getTime();
	}
	
	// Helper method to create a future date for testing
	private Date getFutureDate() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, 1); // Add 1 year to current date
		return cal.getTime();
	}
	
	@Test
	@DisplayName("Test to Update appointment date")
	@Order(1)
	void testUpdateAppointmentDate() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(getFutureDate(), "Description");
		// Get the ID of the first appointment (should be "0")
		String firstAppointmentId = service.appointmentList.get(0).getAppointmentID();
		Date newDate = getFutureDate();
		service.updateAppointmentDate(newDate, firstAppointmentId);
		service.displayAppointmentList();
		assertEquals(newDate, service.getAppointment(firstAppointmentId).getAppointmentDate(), "Appointment date was not updated.");
	}

	@Test
	@DisplayName("Test to Update appointment description.")
	@Order(2)
	void testUpdateAppointmentDesc() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(getFutureDate(), "Description");
		// Get the ID of the first appointment (should be "0")
		String firstAppointmentId = service.appointmentList.get(0).getAppointmentID();
		service.updateAppointmentDesc("Updated Description", firstAppointmentId);
		service.displayAppointmentList();
		assertEquals("Updated Description", service.getAppointment(firstAppointmentId).getAppointmentDesc(), "Appointment description was not updated.");
	}

	@Test
	@DisplayName("Test to ensure that service correctly deletes appointments.")
	@Order(3)
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(getFutureDate(), "Description");
		// Get the ID of the first appointment (should be "0")
		String firstAppointmentId = service.appointmentList.get(0).getAppointmentID();
		service.deleteAppointment(firstAppointmentId);
		service.displayAppointmentList();
		assertEquals(0, service.appointmentList.size(), "The appointment was not deleted.");
	}

	@Test
	@DisplayName("Test to ensure that service can add an appointment.")
	@Order(4)
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(getFutureDate(), "Description");
		service.displayAppointmentList();
		// Get the ID of the first appointment (should be "0")
		String firstAppointmentId = service.appointmentList.get(0).getAppointmentID();
		assertNotNull(service.getAppointment(firstAppointmentId), "Appointment was not added correctly.");
	}
}
