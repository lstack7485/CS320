package task;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
	private final String taskID;
	private String taskName;
	private String taskDesc;
	private static AtomicLong idGenerator = new AtomicLong();
	
	// CONSTRUCTOR
	public Task(String taskName, String taskDesc) {
		// Task ID - auto-generated and limited to 10 characters
		String generatedID = String.valueOf(idGenerator.getAndIncrement());
		if (generatedID.length() > 10) {
			this.taskID = generatedID.substring(0, 10);
		} else {
			this.taskID = generatedID;
		}
		
		// Task Name - limited to 20 characters
		if (taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		} else if (taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		} else {
			this.taskName = taskName;
		}
		
		// Task Description - limited to 50 characters
		if (taskDesc == null || taskDesc.isEmpty()) {
			this.taskDesc = "NULL";
		} else if (taskDesc.length() > 50) {
			this.taskDesc = taskDesc.substring(0, 50);
		} else {
			this.taskDesc = taskDesc;
		}
	}
	
	// GETTERS
	public String getTaskID() {
		return taskID;
	}
	
	public String getTaskName() {
		return taskName;
	}
	
	public String getTaskDesc() {
		return taskDesc;
	}
	
	// SETTERS
	public void setTaskName(String taskName) {
		if (taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		} else if (taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		} else {
			this.taskName = taskName;
		}
	}
	
	public void setTaskDesc(String taskDesc) {
		if (taskDesc == null || taskDesc.isEmpty()) {
			this.taskDesc = "NULL";
		} else if (taskDesc.length() > 50) {
			this.taskDesc = taskDesc.substring(0, 50);
		} else {
			this.taskDesc = taskDesc;
		}
	}
}
