package Test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import Contact.Contact;
import Contact.ContactService;

import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {

	
	@Test
	@DisplayName("Update First Name.")
	@Order(1)
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		service.addContact("Smith", "2155551234", "123 Main Street");
		service.updateFirstName("Logan", "9");
		service.displayContactList();
		assertEquals("Logan", service.getContact("9").getFirstName(), "First name was not updated.");
	}

	@Test
	@DisplayName("Update Last Name.")
	@Order(2)
	void testUpdateLastName() {
		ContactService service = new ContactService();
		service.addContact("Smith", "2155551234", "123 Main Street");
		service.updateLastName("Ella", "11");
		service.displayContactList();
		assertEquals("Ella", service.getContact("11").getLastName(), "Last name was not updated.");
	}

	@Test
	@DisplayName("Test to update phone number.")
	@Order(3)
	void testUpdatePhoneNumber() {
		ContactService service = new ContactService();
		service.addContact("Smith", "2155551234", "123 Main Street");
		service.updateNumber("3333311111", "17");
		//service.displayContactList();
		assertEquals("3333311111", service.getContact("17").getNumber(), "Phone number was not updated.");
	}

	@Test
	@DisplayName("Test to update address.")
	@Order(4)
	void testUpdateAddress() {
		ContactService service = new ContactService();
		service.addContact("Smith", "2155551234", "123 Main Street");
		service.updateAddress("555 College Ave", "15");
		service.displayContactList();
		assertEquals("555 College Ave", service.getContact("15").getAddress(), "Address was not updated.");
	}

	@Test
	@DisplayName("Test to ensure that service correctly deletes contacts.")
	@Order(5)
	void testDeleteContact() {
		ContactService service = new ContactService();
		service.addContact("Smith", "2155551234", "123 Main Street");
		service.deleteContact("17");
		ArrayList<Contact> contactListEmpty = new ArrayList<Contact>();
		service.displayContactList();
		assertEquals(service.contactList, contactListEmpty, "The contact was not deleted.");
	}

	@Test
	@DisplayName("Test to ensure that service can add a contact.")
	@Order(6)
	void testAddContact() {
		ContactService service = new ContactService();
		service.addContact("Smith", "2155551234", "123 Main Street");
		service.displayContactList();
		assertNotNull(service.getContact("0"), "Contact was not added correctly.");
	}

}